package com.example1.android.krishimantra;

public class PlayerConfig {

    PlayerConfig(){

    }
    public static final String API_KEY = "AIzaSyCXBosQKmfEj5YFiK0ISdir_zt8bKloibI";
}
